import ZakatCalculator from "./ZakatCalculator";

function App() {
  return <ZakatCalculator />;
}

export default App;